=== CTL Slot Mr Chicken ===
Tags: bonus, bonus game, casino, chicken, gambling, html5, instant win, mobile, money, poker, slot, slot machine, videopoker, win
Requires at least: 4.3
Tested up to: 4.3

Add Slot Mr Chicken to CTL Arcade plugin

== Description ==
Add Slot Mr Chicken to CTL Arcade plugin


	